n=int(input())
for i in range(1,n):
    print('*'*(n-1))