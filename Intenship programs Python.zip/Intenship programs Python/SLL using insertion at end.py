Python 3.11.9 (tags/v3.11.9:de54cf5, Apr  2 2024, 10:12:12) [MSC v.1938 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.

= RESTART: C:/Users/achyu/OneDrive/Desktop/Intenship programs Python/SLL using insertion at begining.py

= RESTART: C:/Users/achyu/OneDrive/Desktop/Intenship programs Python/SLL using insertion at begining.py
500
400
300
200
100

= RESTART: C:/Users/achyu/OneDrive/Desktop/Intenship programs Python/SLL using insertion at end.py
500
400
300
200
100
Traceback (most recent call last):
  File "C:/Users/achyu/OneDrive/Desktop/Intenship programs Python/SLL using insertion at end.py", line 30, in <module>
    obj.display()
  File "C:/Users/achyu/OneDrive/Desktop/Intenship programs Python/SLL using insertion at end.py", line 23, in display
    temp=temp.prev
AttributeError: 'Node' object has no attribute 'prev'

= RESTART: C:/Users/achyu/OneDrive/Desktop/Intenship programs Python/SLL using insertion at end.py
500
400
300
200
100

= RESTART: C:/Users/achyu/OneDrive/Desktop/Intenship programs Python/SLL using insertion at end.py
Traceback (most recent call last):
  File "C:/Users/achyu/OneDrive/Desktop/Intenship programs Python/SLL using insertion at end.py", line 39, in <module>
    obj.inserttEnd('Achuyth')
AttributeError: 'SLL' object has no attribute 'inserttEnd'. Did you mean: 'insertAtEnd'?

= RESTART: C:/Users/achyu/OneDrive/Desktop/Intenship programs Python/SLL using insertion at end.py
500
400
300
200
100

= RESTART: C:/Users/achyu/OneDrive/Desktop/Intenship programs Python/SLL using insertion at end.py
500
400
300
200
100
Achuyth
karanam
>>> 
= RESTART: C:/Users/achyu/OneDrive/Desktop/Intenship programs Python/SLL using insertion at end.py
500
400
300
200
100
Achuyth
karanam
>>> 
= RESTART: C:/Users/achyu/OneDrive/Desktop/Intenship programs Python/SLL using insertion at end.py
The count is:  7
500
400
300
200
100
Achuyth
karanam
>>> 
= RESTART: C:/Users/achyu/OneDrive/Desktop/Intenship programs Python/SLL using insertion at end.py
500
400
300
200
100
Achuyth
karanam
The count is:  7
