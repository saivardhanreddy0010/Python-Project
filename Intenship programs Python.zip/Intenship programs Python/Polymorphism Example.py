#Polymorphism: A one entity can be defined in many forms is known as polymorphism
#There are two types compile time(function overloading) and runtime(function overiding)
#function overloading:A function with same name with different parameter
#Function overiding:A function with same parameter is known as function overiding
#two class required for function overiding and both should be inherited
de
