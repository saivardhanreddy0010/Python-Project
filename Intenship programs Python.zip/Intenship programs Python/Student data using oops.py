#Object oriented programming
#class: it is blueprint of a object
#a class contain data and functions
#class can be created by using class keyword
class Student:
    name='Achyuth'
    rollno=63
    branch='ECE'
    cgpa=8.90
print(Student.name)
print(Student.rollno)
print(Student.branch)
print(Student.cgpa)
    
