try:
  arr=[10,20,30,4,5]
  print (arr[12])

except Exception:
    print("cannot access out of range")
else:
    print('There is no exception in my code')
