#1,2,4,8,16
for i in range(0,5):
    print(2**i)