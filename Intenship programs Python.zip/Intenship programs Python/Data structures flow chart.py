#Data structures
#types of linked list:
#            1.Linear datastructure
#            2.Non linear datastructure
#Linear Datastructure:
#1.arrays:1D-array,2D-array
#2.Linkedlists:single Linkedlist,double linked list,circular linked list
#3.Stack
#4.Queue
#Non linear datastructure:
#1.Trees
#2.B-graphs
#3.Heaps
