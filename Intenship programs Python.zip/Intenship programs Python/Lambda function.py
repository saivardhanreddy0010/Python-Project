#lambda function
#A lambda is anynomous function
#Syntax variable=lamda arguments:expression
res=lambda nums:max(nums)
print(res([1,9,5,3,7]))



            
