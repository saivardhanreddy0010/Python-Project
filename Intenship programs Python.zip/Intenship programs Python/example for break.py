while True:
    name=input('Enter your name')
    choice=input('Do you want to continue(y/n)')
    print("hello",name)
    if choice=='n':
        break