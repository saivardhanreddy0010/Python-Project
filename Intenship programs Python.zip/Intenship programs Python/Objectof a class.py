#Object: It is an real world entity
#object is an instantance of a class
#object contain attributes,behaviours,identity
#while creating object memory will get allocated
class Student:
    name='Achyuth'
    rollno=63
    branch='ECE'
    cgpa=8.90
s1=Student
print(s1.name,s1.rollno)
