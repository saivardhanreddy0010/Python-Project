#numpy is a python library which is used to work with arrays numpy was created in the year 2005
#numpy stands for numerical python
#numpy is faster then list because elements in numpy stored  contigous memory allocation
#array element can fetch using index

import numpy as np
arr=np.array([1,2,3,4])
print(arr)
